package message;

public interface iMessageSource {
	String fetchMessage();

}
