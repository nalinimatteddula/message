package message;

public class MessageFileSource implements iMessageSource {
	
	@Override
	public String fetchMessage() {
		return "File Message: Interfaces play a key role ";
	}

}
