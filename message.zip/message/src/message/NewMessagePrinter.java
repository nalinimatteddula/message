package message;

public class NewMessagePrinter {

}
