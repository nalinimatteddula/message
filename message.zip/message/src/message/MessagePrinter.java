package message;

public class MessagePrinter {
	
	private iMessageSource messageSource;

	public MessagePrinter(iMessageSource messageSource) {
		this.messageSource = messageSource;
	}
	
	public void printMessage() {
		System.out.println(messageSource.fetchMessage());
	}
	

}
