package message;

public class MessageDBSource implements iMessageSource{
 
	@Override
	public String fetchMessage() {
		return "DB Message:Welcome to the world of interfaces ";
	}
}
